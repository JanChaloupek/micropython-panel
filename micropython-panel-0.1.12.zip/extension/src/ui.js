// ui.js
const vscode = require('vscode');
const path = require('path');
const fs = require('fs');
const { logger } = require('./logging');

/**
 * Vytvoří tlačítka ve status baru pro všechny příkazy definované
 * v nastavení `micropython.commands`.
 *
 * Každé tlačítko:
 *  - má text (cmd.name)
 *  - volá dynamicky registrovaný příkaz micropython.runCommand.<id>
 *  - může mít vlastní barvu
 *
 * Pokud nejsou definovány žádné příkazy, funkce nic nevytvoří.
 *
 * @param {vscode.ExtensionContext} context - kontext rozšíření
 * @param {Array<Object>} commands - seznam příkazů z nastavení
 * @param {vscode.OutputChannel} out - výstupní log kanál
 */
function createStatusButtons(context, commands, out) {
    if (!commands?.length) {
        logger.warn(out, "No commands configured → status bar not created.");
        return;
    }

    for (const cmd of commands) {
        const btn = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
        btn.text = cmd.name;
        btn.command = `micropython.runCommand.${cmd.id}`;
        if (cmd.color) btn.color = cmd.color;
        btn.show();
        context.subscriptions.push(btn);
    }

    logger.info(out, "Status bar buttons created.");
}

/**
 * Otevře webview panel s UI pro MicroPython.
 *
 * Panel:
 *  - načte HTML z media/panel.html
 *  - pošle do webview seznam příkazů (commands)
 *  - umožňuje klikáním spouštět příkazy přes postMessage
 *
 * Webview běží izolovaně, takže HTML/CSS/JS musí být načteny
 * přes `extensionPath` a `asWebviewUri`.
 *
 * @param {vscode.ExtensionContext} context - kontext rozšíření
 * @param {Array<Object>} commands - seznam příkazů z nastavení
 * @param {vscode.OutputChannel} out - výstupní log kanál
 */
function openPanel(context, commands, out) {
    const panel = vscode.window.createWebviewPanel(
        "micropythonPanel",          // interní ID panelu
        "MicroPython Panel",         // titulek panelu
        vscode.ViewColumn.Beside,    // kde se panel otevře
        { enableScripts: true }      // povolit JS ve webview
    );

    const htmlPath = path.join(context.extensionPath, 'media', 'panel.html');
    let html = fs.readFileSync(htmlPath, 'utf8');

    panel.webview.html = html;

    // Pošleme seznam příkazů do webview
    panel.webview.postMessage({ commands });

    logger.info(out, "Panel opened.");
}

module.exports = { createStatusButtons, openPanel };
