// extension.js
const vscode = require('vscode');
const { logger } = require('./logging');
const { getSetting } = require('./settings');
const { registerDynamicCommands } = require('./commands');
const { createStatusButtons, openPanel } = require('./ui');

/**
 * Detekuje, zda je aktuální workspace MicroPython projekt.
 *
 * Projekt je považován za MicroPython, pokud obsahuje:
 *  - main.py, code.py nebo boot.py
 *  - nebo skripty ve .vscode: upload.ps1, list.ps1, wipe.ps1
 *
 * Tato detekce zabraňuje aktivaci rozšíření v projektech,
 * kde by nedávalo smysl (např. webové projekty, C#, atd.).
 *
 * @returns {Promise<boolean>} - true pokud jde o MicroPython projekt
 */
async function isMicroPythonProject() {
    const pyFiles = await vscode.workspace.findFiles("**/{main.py,code.py,boot.py}");
    const psScripts = await vscode.workspace.findFiles("**/.vscode/{upload.ps1,list.ps1,wipe.ps1}");
    return pyFiles.length > 0 || psScripts.length > 0;
}

/**
 * Hlavní aktivační funkce rozšíření.
 *
 * Provádí:
 *  1) vytvoření logovacího kanálu
 *  2) detekci MicroPython projektu
 *  3) načtení nastavení (commands, enableStatusToolbar)
 *  4) registraci dynamických příkazů
 *  5) vytvoření status bar tlačítek
 *  6) registraci příkazu pro otevření panelu
 *
 * Všechny části jsou modulární a oddělené v samostatných souborech:
 *  - settings.js  → načítání nastavení
 *  - commands.js  → dynamické příkazy
 *  - ui.js        → status bar + panel
 *
 * @param {vscode.ExtensionContext} context - kontext rozšíření
 */
async function activate(context) {
    const out = vscode.window.createOutputChannel("MicroPython Panel");
    logger.info(out, "Extension activated.");

    // 1) Detekce projektu
    if (!await isMicroPythonProject()) {
        logger.warn(out, "Not a MicroPython project → extension will not initialize.");
        return;
    }

    logger.info(out, "MicroPython project detected.");

    // 2) Načtení příkazů z nastavení
    const commands = getSetting("commands", out);

    // 3) Registrace dynamických příkazů
    registerDynamicCommands(context, commands, out);

    // 4) Status bar tlačítka
    if (getSetting("enableStatusToolbar", out)) {
        createStatusButtons(context, commands, out);
    }

    // 5) Panel
    context.subscriptions.push(
        vscode.commands.registerCommand("micropython.openPanel", () => {
            openPanel(context, commands, out);
        })
    );

    logger.info(out, "Initialization complete.");
}

exports.activate = activate;

function deactivate() {}

exports.deactivate = deactivate;
