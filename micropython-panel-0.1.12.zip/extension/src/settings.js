// settings.js
const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const { logger } = require('./logging');

/**
 * Sanitizuje obsah JSON souboru:
 * - odstraní BOM
 * - odstraní komentáře (// a /* */)
 * - odstraní trailing commas (čárky před } nebo ])
 *
 * Cílem je umožnit načtení i "neúplně validního" JSON,
 * který studenti často vytvoří v settings.json.
 *
 * @param {string} raw - původní obsah souboru
 * @returns {string} - očištěný JSON připravený k parse
 */
function sanitizeJson(raw) {
    let cleaned = raw;

    cleaned = cleaned.replace(/^\uFEFF/, "");             // BOM
    cleaned = cleaned.replace(/\/\/.*$/gm, "");           // // komentáře
    cleaned = cleaned.replace(/\/\*[\s\S]*?\*\//gm, "");  // /* */ komentáře
    cleaned = cleaned.replace(/,\s*([}\]])/g, "$1");      // trailing commas

    return cleaned;
}

/**
 * Pokusí se načíst a parse-nout settings.json přímo z disku.
 * Vrací objekt nebo null, pokud:
 * - soubor neexistuje
 * - nebo ani po sanitizaci nejde parse-nout
 *
 * @param {vscode.WorkspaceFolder} folder - složka workspace
 * @returns {object|null}
 */
function loadFolderSettingsRaw(folder) {
    const settingsPath = path.join(folder.uri.fsPath, ".vscode", "settings.json");

    if (!fs.existsSync(settingsPath)) {
        return null;
    }

    try {
        const raw = fs.readFileSync(settingsPath, "utf8");
        const cleaned = sanitizeJson(raw);
        return JSON.parse(cleaned);
    } catch {
        return null;
    }
}

/**
 * Zjistí, zda je hodnota "neprázdná".
 * Používá se pro rozhodování, zda má nastavení přednost.
 *
 * @param {*} value
 * @returns {boolean}
 */
function isNonEmpty(value) {
    if (value === undefined || value === null) return false;
    if (Array.isArray(value) && value.length === 0) return false;
    if (typeof value === "string" && value.trim() === "") return false;
    if (typeof value === "object" && Object.keys(value).length === 0) return false;
    return true;
}

/**
 * Načte nastavení micropython.<settingName> s vlastní robustní logikou:
 *
 * 1) Pokusí se načíst settings.json ručně z disku (RAW mód)
 *    - toleruje trailing commas, komentáře, BOM
 *    - pokud najde neprázdnou hodnotu → použije ji
 *
 * 2) Pokud RAW nenajde nic, použije VS Code API:
 *    - workspace settings (pokud existují)
 *    - folder settings
 *    - user settings
 *    - default settings
 *
 * 3) Prázdné hodnoty se ignorují (nemají přednost)
 *
 * @param {string} settingName - název nastavení bez prefixu (např. "commands")
 * @param {vscode.OutputChannel} out - výstupní log kanál
 * @returns {*} - nalezená hodnota nebo undefined
 */
function getSetting(settingName, out) {
    const folders = vscode.workspace.workspaceFolders || [];
    const isWorkspace = vscode.workspace.workspaceFile !== undefined;

    // ------------------------------------------------------------
    // 1) RAW folder settings (robustní mód)
    // ------------------------------------------------------------
    for (const folder of folders) {
        const rawSettings = loadFolderSettingsRaw(folder);

        if (rawSettings && rawSettings[`micropython.${settingName}`] !== undefined) {
            const value = rawSettings[`micropython.${settingName}`];

            if (isNonEmpty(value)) {
                logger.info(out, `Using ${settingName} from RAW folder settings`);
                return value;
            }
        }
    }

    // ------------------------------------------------------------
    // 2) Workspace settings (VS Code API)
    // ------------------------------------------------------------
    if (isWorkspace) {
        const wsConfig = vscode.workspace.getConfiguration("micropython");
        const inspected = wsConfig.inspect(settingName);

        if (inspected && isNonEmpty(inspected.workspaceValue)) {
            logger.info(out, `Using ${settingName} from WORKSPACE settings`);
            return inspected.workspaceValue;
        }
    }

    // ------------------------------------------------------------
    // 3) Folder settings (VS Code API)
    // ------------------------------------------------------------
    for (const folder of folders) {
        const folderConfig = vscode.workspace.getConfiguration("micropython", folder.uri);
        const inspected = folderConfig.inspect(settingName);

        if (inspected && isNonEmpty(inspected.workspaceFolderValue)) {
            logger.info(out, `Using ${settingName} from folder settings`);
            return inspected.workspaceFolderValue;
        }
    }

    // ------------------------------------------------------------
    // 4) User settings
    // ------------------------------------------------------------
    const globalConfig = vscode.workspace.getConfiguration("micropython");
    const inspectedGlobal = globalConfig.inspect(settingName);

    if (inspectedGlobal && isNonEmpty(inspectedGlobal.globalValue)) {
        logger.info(out, `Using ${settingName} from USER settings`);
        return inspectedGlobal.globalValue;
    }

    // ------------------------------------------------------------
    // 5) Default settings
    // ------------------------------------------------------------
    if (inspectedGlobal && isNonEmpty(inspectedGlobal.defaultValue)) {
        logger.info(out, `Using ${settingName} from DEFAULT settings`);
        return inspectedGlobal.defaultValue;
    }

    // ------------------------------------------------------------
    // 6) Nic nenalezeno
    // ------------------------------------------------------------
    logger.warn(out, `No non-empty value found for '${settingName}'`);
    return undefined;
}

module.exports = { getSetting };
