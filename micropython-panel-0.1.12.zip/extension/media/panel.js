// panel.js (webview script)
const vscode = acquireVsCodeApi();

/**
 * Listener pro zprávy z VS Code extension.
 * Extension posílá seznam příkazů → vykreslíme tlačítka.
 */
window.addEventListener("message", event => {
    if (event.data.commands) {
        renderButtons(event.data.commands);
    }
});

/**
 * Vykreslí tlačítka podle seznamu příkazů.
 *
 * @param {Array<Object>} commands - seznam příkazů z nastavení
 */
function renderButtons(commands) {
    const toolbar = document.getElementById("toolbar");
    toolbar.innerHTML = "";

    for (const cmd of commands) {
        const btn = document.createElement("button");
        btn.textContent = cmd.name;

        if (cmd.color) {
            btn.style.setProperty("--btn-color", cmd.color);
        }

        btn.onclick = () => {
            vscode.postMessage({ command: cmd.id });
        };

        toolbar.appendChild(btn);
    }
}
